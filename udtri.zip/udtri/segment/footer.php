<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <strong>UD. TRI L</strong>. All Rights Reserved</span>
        </div>
        <div class="copyright text-center mt-1">

            <span>Designed & Developed by: <a href="https://anemos.id/">Anemos.id</a></span>

        </div>
    </div>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
</footer>
<!-- End of Footer -->